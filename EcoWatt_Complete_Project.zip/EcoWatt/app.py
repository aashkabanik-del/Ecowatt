import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import date

st.set_page_config(page_title="EcoWatt | Home Energy Lab", page_icon="⚡", layout="wide")

st.markdown("""
<style>
.stApp { background: linear-gradient(180deg, #f5f9ff 0%, #f7fbf8 100%); }
.hero { padding: 1.6rem 1.8rem; border-radius: 22px; background: linear-gradient(120deg, #112a46, #176b67); color: white; margin-bottom: 1rem; box-shadow: 0 12px 28px rgba(20,55,75,.14); }
.hero h1 { font-size: 2.4rem; margin: 0; color: white; }
.hero p { font-size: 1.03rem; margin: .5rem 0 0 0; color: #e2f6f1; }
div[data-testid="stMetric"] { background: white; border: 1px solid #e3ecef; padding: 1rem; border-radius: 16px; box-shadow: 0 4px 14px rgba(20,55,75,.04); }
</style>
""", unsafe_allow_html=True)

def solar_energy_kwh(capacity_kw, sunlight_hours, efficiency_percent):
    """Estimate usable daily solar energy in kilowatt-hours."""
    return capacity_kw * sunlight_hours * (efficiency_percent / 100)

def rupees(value):
    return f"₹{value:,.2f}"

st.sidebar.title("⚡ EcoWatt Controls")
st.sidebar.caption("Change the values to explore different scenarios.")
page = st.sidebar.radio("Workspace", ["Energy Dashboard", "Appliance Planner", "About the Project"])

st.sidebar.divider()
st.sidebar.subheader("Solar system")
capacity_kw = st.sidebar.slider("Solar capacity (kW)", 0.5, 10.0, 3.0, 0.5)
sunlight_hours = st.sidebar.slider("Effective sunlight (hours/day)", 1.0, 8.0, 5.0, 0.5)
efficiency = st.sidebar.slider("System efficiency (%)", 50, 100, 80, 5)
tariff = st.sidebar.number_input("Electricity tariff (₹/kWh)", min_value=0.0, max_value=100.0, value=7.5, step=0.5)
home_use_daily = st.sidebar.number_input("Home use (kWh/day)", min_value=0.0, max_value=200.0, value=8.0, step=0.5)
installation_cost = st.sidebar.number_input("Estimated installation cost (₹)", min_value=0, max_value=5000000, value=180000, step=5000)

daily_solar = solar_energy_kwh(capacity_kw, sunlight_hours, efficiency)
monthly_solar = daily_solar * 30
annual_solar = daily_solar * 365
monthly_home_use = home_use_daily * 30
monthly_value = monthly_solar * tariff
annual_value = annual_solar * tariff
offset = min(100.0, monthly_solar / monthly_home_use * 100) if monthly_home_use > 0 else 0.0
remaining = max(0.0, monthly_home_use - monthly_solar)
payback = installation_cost / annual_value if annual_value > 0 else None

st.markdown("""
<div class="hero">
<h1>⚡ EcoWatt</h1>
<p>Interactive home energy and solar planning dashboard — built with beginner-friendly Python.</p>
</div>
""", unsafe_allow_html=True)

if page == "Energy Dashboard":
    st.subheader("Your energy snapshot")
    st.caption(f"Estimates generated on {date.today().strftime('%d %B %Y')}. Adjust the controls in the sidebar.")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Solar per day", f"{daily_solar:.2f} kWh")
    c2.metric("Solar per month", f"{monthly_solar:.1f} kWh")
    c3.metric("Potential monthly value", rupees(monthly_value))
    c4.metric("Home energy offset", f"{offset:.0f}%")

    left, right = st.columns(2)
    with left:
        st.markdown("### Monthly energy balance")
        balance = pd.DataFrame({
            "Category": ["Home consumption", "Solar generation"],
            "Energy (kWh/month)": [monthly_home_use, monthly_solar],
        })
        fig = px.bar(balance, x="Category", y="Energy (kWh/month)", color="Category",
                     text_auto=".1f", title="Home use compared with solar generation",
                     color_discrete_sequence=["#315b78", "#22a699"])
        fig.update_layout(showlegend=False, plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.markdown("### Estimated electricity value")
        periods = pd.DataFrame({
            "Period": ["Daily", "Monthly", "Annual"],
            "Estimated value (₹)": [daily_solar * tariff, monthly_value, annual_value],
        })
        fig2 = px.line(periods, x="Period", y="Estimated value (₹)", markers=True,
                       title="Estimated value of generated electricity")
        fig2.update_traces(line_width=4, marker_size=10, line_color="#16877d")
        fig2.update_layout(plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown("### Quick insights")
    a, b, c = st.columns(3)
    a.info(f"Estimated monthly household use: **{monthly_home_use:.1f} kWh**.")
    if monthly_solar >= monthly_home_use:
        b.success("Estimated solar generation meets or exceeds the entered monthly use.")
    else:
        b.warning(f"Estimated energy still needed: **{remaining:.1f} kWh/month**.")
    if payback is not None:
        c.info(f"Simplified installation payback: **{payback:.1f} years**.")
    else:
        c.info("Enter a non-zero tariff to estimate payback.")

    report = pd.DataFrame([{
        "Solar capacity (kW)": capacity_kw,
        "Sunlight hours/day": sunlight_hours,
        "Efficiency (%)": efficiency,
        "Tariff (₹/kWh)": tariff,
        "Home use (kWh/day)": home_use_daily,
        "Solar daily (kWh)": round(daily_solar, 2),
        "Solar monthly (kWh)": round(monthly_solar, 2),
        "Solar annual (kWh)": round(annual_solar, 2),
        "Potential monthly value (₹)": round(monthly_value, 2),
        "Potential annual value (₹)": round(annual_value, 2),
        "Home energy offset (%)": round(offset, 2),
        "Installation cost (₹)": installation_cost,
        "Simple payback (years)": round(payback, 2) if payback is not None else None,
    }])
    st.download_button("⬇️ Download scenario as CSV", report.to_csv(index=False).encode("utf-8"),
                       "ecowatt_scenario.csv", "text/csv")

elif page == "Appliance Planner":
    st.subheader("Appliance energy planner")
    st.write("Edit the example appliances to estimate your household's electricity use.")
    sample = pd.DataFrame([
        {"Appliance": "LED bulbs", "Quantity": 5, "Power (W)": 9, "Hours/day": 6.0},
        {"Appliance": "Ceiling fan", "Quantity": 3, "Power (W)": 70, "Hours/day": 8.0},
        {"Appliance": "Television", "Quantity": 1, "Power (W)": 100, "Hours/day": 4.0},
        {"Appliance": "Refrigerator", "Quantity": 1, "Power (W)": 180, "Hours/day": 8.0},
        {"Appliance": "Laptop", "Quantity": 1, "Power (W)": 65, "Hours/day": 5.0},
    ])
    edited = st.data_editor(sample, num_rows="dynamic", use_container_width=True)
    edited["Daily energy (kWh)"] = edited["Quantity"] * edited["Power (W)"] * edited["Hours/day"] / 1000
    edited["Monthly energy (kWh)"] = edited["Daily energy (kWh)"] * 30
    edited["Monthly cost (₹)"] = edited["Monthly energy (kWh)"] * tariff
    daily_total = edited["Daily energy (kWh)"].sum()
    monthly_total = edited["Monthly energy (kWh)"].sum()
    cost_total = edited["Monthly cost (₹)"].sum()
    x, y, z = st.columns(3)
    x.metric("Daily use", f"{daily_total:.2f} kWh")
    y.metric("Monthly use", f"{monthly_total:.1f} kWh")
    z.metric("Estimated monthly cost", rupees(cost_total))
    fig = px.bar(edited, x="Appliance", y="Monthly energy (kWh)", color="Appliance",
                 title="Monthly energy by appliance", text_auto=".1f")
    fig.update_layout(showlegend=False, xaxis_tickangle=-20, plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)")
    st.plotly_chart(fig, use_container_width=True)
    st.download_button("⬇️ Download appliance report (CSV)", edited.to_csv(index=False).encode("utf-8"),
                       "ecowatt_appliance_report.csv", "text/csv")
    st.caption("Estimates only: actual power varies by appliance model and operating conditions.")

else:
    st.subheader("About EcoWatt")
    st.write("EcoWatt is an educational project that applies Class 12 Physics and Mathematics to home energy planning.")
    st.markdown("### Core formulas")
    st.latex(r"E = P \\times t")
    st.write("Convert watt-hours to kilowatt-hours:")
    st.latex(r"E_{kWh} = \\frac{P_W \\times t_h}{1000}")
    st.write("Estimated usable solar generation:")
    st.latex(r"E_{solar} = P_{solar,kW} \\times H_{sun} \\times \\eta")
    st.write("Estimated electricity value:")
    st.latex(r"\\text{Value} = E_{kWh} \\times \\text{Tariff}")
    st.markdown("### Technologies used")
    st.markdown("- Python for calculations and logic\n- Streamlit for the interactive web interface\n- Pandas for tabular data\n- Plotly for charts\n- CSV export for downloadable reports")
    st.warning("This project gives simplified educational estimates, not professional electrical or financial advice. Real output and savings depend on weather, shading, installation, equipment, tariffs, and local rules.")

st.sidebar.divider()
st.sidebar.caption("Python • Streamlit • Pandas • Plotly")

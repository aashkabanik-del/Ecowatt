# ⚡ EcoWatt — Home Energy & Solar Dashboard

An interactive, beginner-friendly web app for estimating solar generation, household appliance energy use, potential electricity value, and a simplified solar payback period.

Built with Python, Streamlit, Pandas, and Plotly. The main calculations use Class 12-level Physics and Mathematics.

## Features
- Interactive solar capacity, sunlight, efficiency, tariff, and home-use controls
- Daily, monthly, and annual solar generation estimates
- Comparison of home energy use with estimated solar generation
- Estimated electricity value and simplified installation payback
- Editable household appliance planner
- Interactive charts
- Downloadable CSV reports

## Physics and maths
Electrical energy:
\[
E = P \\times t
\]

When power is in watts and time is in hours:
\[
E_{kWh} = \\frac{P_W \\times t_h}{1000}
\]

Estimated usable solar generation:
\[
E_{solar} = P_{solar,kW} \\times H_{sun} \\times \\eta
\]

Appliance daily consumption:
\[
E_{daily,kWh} = \\frac{Quantity \\times Power(W) \\times Hours/day}{1000}
\]

Estimated electricity value:
\[
Value = Energy(kWh) \\times Tariff
\]

## Run locally
Install Python 3.10+.

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

If `python` does not work on your system, try `python3`.

## Publish on GitHub
1. Create a new public repository on GitHub.
2. Upload `app.py`, `requirements.txt`, `README.md`, `.gitignore`, and `LICENSE`.
3. Commit the files.

## Deploy as a website
Use [Streamlit Community Cloud](https://share.streamlit.io/). Connect your GitHub repository, choose `app.py` as the main file, and deploy. See the [official deployment guide](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy).

## Project structure
```text
EcoWatt/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── LICENSE
```

## Presentation summary
EcoWatt is an interactive home-energy and solar-planning dashboard. It estimates solar electricity generation, household appliance consumption, potential electricity-bill value, and a simplified payback period. It applies Class 12 concepts of power, energy, and efficiency. Streamlit provides the interface, Pandas manages tables, and Plotly creates the charts.

## Disclaimer
All results are rough educational estimates. Actual solar output, bill savings, and payback depend on location, season, weather, shading, system design, equipment, tariffs, local rules, and maintenance. The app is not a professional solar quotation.

## License
MIT License.
